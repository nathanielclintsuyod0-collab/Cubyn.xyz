# Seraphyx SMP — Professional Website

A multi-page, Minecraft-inspired medieval fantasy website for GitHub Pages.

## Pages
- `/index.html` — landing page
- `/pages/shop.html` — shop/catalog
- `/pages/ranks.html` — 38-rank progression
- `/pages/wiki.html` — server codex
- `/pages/rules.html` — rules
- `/pages/status.html` — server status

## Configure
Edit `assets/config.js`:
- `serverIP`
- `discord`
- `store`
- `liveStatus`
- `statusEndpoint`
- shop products/prices/links
- rank requirements

## Connecting a real shop
The included shop is a catalog UI. Replace each product's `url` with your real checkout/product URL, or point the Store button to your existing store platform.

The website intentionally does NOT contain payment processing or server credentials.

## GitHub Pages
Repository → Settings → Pages → Source: GitHub Actions.

Push to `main` and the included workflow deploys the site.

## Recommended next integrations
For live Minecraft data, use a small server-side API rather than exposing plugin/database credentials to the browser. The frontend can then display:
- online player count
- server status
- player lookup
- leaderboards
- rank information
- playtime/economy statistics

Never commit:
- Discord bot tokens
- database passwords
- Minecraft panel/API secrets
- Firebase private keys
- payment secrets
